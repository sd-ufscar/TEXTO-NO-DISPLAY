// Code your testbench here
// or browse Examples

`timescale 1ns/1ps

module texto_display_tb;

    // Entradas do circuito
    reg clock_50;

    // Saídas dos displays de 7 segmentos
    wire [7:0] HEX0;
    wire [7:0] HEX1;
    wire [7:0] HEX2;
    wire [7:0] HEX3;
    wire [7:0] HEX4;
    wire [7:0] HEX5;

    // Instância do módulo principal
    texto_display uut (
        .clock_50(clock_50),
        .HEX0(HEX0),
        .HEX1(HEX1),
        .HEX2(HEX2),
        .HEX3(HEX3),
        .HEX4(HEX4),
        .HEX5(HEX5)
    );

    // Geração do clock de 50 MHz
    // Período = 20 ns
    initial begin
        clock_50 = 1'b0;
        forever #10 clock_50 = ~clock_50;
    end

    // Tempo de simulação
    initial begin
        $dumpfile("texto_display.vcd");
        $dumpvars(0, texto_display_tb);

        #1000000; // 1 ms de simulação

        $finish;
    end

endmodule
