// Code your design here
// Copyright (C) 2023  Intel Corporation. All rights reserved.
// Your use of Intel Corporation's design tools, logic functions 
// and other software and tools, and any partner logic 
// functions, and any output files from any of the foregoing 
// (including device programming or simulation files), and any 
// associated documentation or information are expressly subject 
// to the terms and conditions of the Intel Program License 
// Subscription Agreement, the Intel Quartus Prime License Agreement,
// the Intel FPGA IP License Agreement, or other applicable license
// agreement, including, without limitation, that your use is for
// the sole purpose of programming logic devices manufactured by
// Intel and sold by Intel or its authorized distributors.  Please
// refer to the applicable agreement for further details, at
// https://fpgasoftware.intel.com/eula.

// PROGRAM		"Quartus Prime"
// VERSION		"Version 23.1std.0 Build 991 11/28/2023 SC Lite Edition"
// CREATED		"Thu Oct 22 12:18:42 2026"

module texto_display(
	clock_50,
	HEX0,
	HEX1,
	HEX2,
	HEX3,
	HEX4,
	HEX5
);


input wire	clock_50;
output wire	[7:0] HEX0;
output wire	[7:0] HEX1;
output wire	[7:0] HEX2;
output wire	[7:0] HEX3;
output wire	[7:0] HEX4;
output reg	[7:0] HEX5;

wire	[5:0] ad;
wire	clk0;
wire	[7:0] hex_ALTERA_SYNTHESIZED0;
reg	[7:0] hex_ALTERA_SYNTHESIZED1;
reg	[7:0] hex_ALTERA_SYNTHESIZED2;
reg	[7:0] hex_ALTERA_SYNTHESIZED3;
reg	[7:0] hex_ALTERA_SYNTHESIZED4;
  wire	[8:0] q;





contador_01_display	b2v_inst2(
	.clock(clk0),
	.q(q));


contador_02_display	b2v_inst3(
  .clock(q[8]),
	.q(ad));


memory_rom_display	b2v_inst4(
  .clock(q[8]),
	.address(ad),
	.q(hex_ALTERA_SYNTHESIZED0));


  always@(posedge q[8])
begin
	begin
	hex_ALTERA_SYNTHESIZED1[7:0] <= hex_ALTERA_SYNTHESIZED0[7:0];
	end
end


  always@(posedge q[8])
begin
	begin
	hex_ALTERA_SYNTHESIZED2[7:0] <= hex_ALTERA_SYNTHESIZED1[7:0];
	end
end


  always@(posedge q[8])
begin
	begin
	hex_ALTERA_SYNTHESIZED3[7:0] <= hex_ALTERA_SYNTHESIZED2[7:0];
	end
end


  always@(posedge q[8])
begin
	begin
	hex_ALTERA_SYNTHESIZED4[7:0] <= hex_ALTERA_SYNTHESIZED3[7:0];
	end
end


  always@(posedge q[8])
begin
	begin
	HEX5[7:0] <= hex_ALTERA_SYNTHESIZED4[7:0];
	end
end

assign	HEX0 = hex_ALTERA_SYNTHESIZED0;
assign	clk0 = clock_50;
assign	HEX1 = hex_ALTERA_SYNTHESIZED1;
assign	HEX2 = hex_ALTERA_SYNTHESIZED2;
assign	HEX3 = hex_ALTERA_SYNTHESIZED3;
assign	HEX4 = hex_ALTERA_SYNTHESIZED4;

endmodule
module contador_01_display (
    input  wire        clock,
  output reg  [8:0] q
);

    initial q = 8'd0;

    always @(posedge clock) begin
        q <= q + 1'b1;
    end

endmodule
module contador_02_display (
    input  wire       clock,
    output reg  [5:0] q
);

    initial q = 6'd0;

    always @(posedge clock) begin
        q <= q + 1'b1;
    end

endmodule
module memory_rom_display (
    input  wire       clock,
    input  wire [5:0] address,
    output reg  [7:0] q
);

    always @(posedge clock) begin
        case (address)

            // Numeros de 0 a 9
            6'd0:  q <= 8'b11000000; // 0
            6'd1:  q <= 8'b11111001; // 1
            6'd2:  q <= 8'b10100100; // 2
            6'd3:  q <= 8'b10110000; // 3
            6'd4:  q <= 8'b10011001; // 4
            6'd5:  q <= 8'b10010010; // 5
            6'd6:  q <= 8'b10000010; // 6
            6'd7:  q <= 8'b11111000; // 7
            6'd8:  q <= 8'b10000000; // 8
            6'd9:  q <= 8'b10010000; // 9

            // Algumas letras
            6'd10: q <= 8'b10001000; // A
            6'd11: q <= 8'b10000011; // b
            6'd12: q <= 8'b11000110; // C
            6'd13: q <= 8'b10100001; // d
            6'd14: q <= 8'b10000110; // E
            6'd15: q <= 8'b10001110; // F
            6'd16: q <= 8'b11000010; // G aproximado
            6'd17: q <= 8'b10001001; // H
            6'd18: q <= 8'b11111001; // I aproximado
            6'd19: q <= 8'b1110001;  // J aproximado

            // Espaco em branco
            default: q <= 8'b11111111;

        endcase
    end

endmodule